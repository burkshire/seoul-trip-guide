const scope=new URL(self.registration.scope);
const prefix='korea-trip:'+scope.href+':',cacheName=prefix+'v24';
const imageCache='korea-guide-media:'+scope.href+':v1',thumbCache='korea-guide-thumbs:'+scope.href+':v1';
const files=['index.html','guide-mobile.html','itinerary.html','guide-library.json','style.css','stores.js','app.js?v=release-24','site.js?v=images-15','seoul.svg'].map(n=>new URL(n,scope).href);
function clean(response){const headers=new Headers(response.headers);headers.delete('content-encoding');headers.delete('content-length');return new Response(response.body,{status:response.status,statusText:response.statusText,headers});}
self.addEventListener('install',event=>event.waitUntil((async()=>{
 const cache=await caches.open(cacheName);
 await Promise.all(files.map(async url=>{const response=await fetch(new Request(url,{cache:'reload'}));if(!response.ok)throw Error('Offline file unavailable');await cache.put(url,clean(response));}));
 await self.skipWaiting();
})()));
self.addEventListener('activate',event=>event.waitUntil((async()=>{
 for(const key of await caches.keys())if(key.startsWith(prefix)&&key!==cacheName)await caches.delete(key);
 await self.clients.claim();
})()));
let libraryTask;
async function library(){if(!libraryTask)libraryTask=(async()=>{const saved=await caches.match(new URL('guide-library.json',scope).href,{cacheName});return saved?await saved.json():null;})();return libraryTask;}
function esc(s){return String(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
async function entryResponse(id){
 const data=await library(),item=data&&data.entries[id];if(!item)return null;
 let body=item.html.replace(/data-src="\.\/guide-media\//g,'src="'+scope.href+'guide-media/').replace(/href="\.\/guide-media\//g,'href="'+scope.href+'guide-media/');
 body=body.replace(/<span class="image-state">.*?<\/span>/g,'').replace(/<button class="image-retry"[^>]*>.*?<\/button>/g,'');
 const doc='<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+esc(item.title)+' · 首尔百事通</title><style>'+data.css+'</style><body><main><header><strong>首尔百事通</strong><nav><a href="'+scope.href+'guide-mobile.html#guide-'+id+'">返回攻略</a><a href="'+scope.href+'itinerary.html#day-'+item.day+'">按天行程</a></nav></header><h1>'+item.titleHtml+'</h1><p class="entry-area">'+esc(item.area)+'</p>'+item.marks+'<article class="entry-content">'+body+'</article><footer>文字、时间、配图和颜色标记来自原攻略。</footer></main></body></html>';
 return new Response(doc,{headers:{'Content-Type':'text/html; charset=utf-8'}});
}
self.addEventListener('fetch',event=>{
 const request=event.request;if(request.method!=='GET'||!request.url.startsWith(scope.href))return;
 const url=new URL(request.url),path=url.pathname.slice(scope.pathname.length);
 if(path.startsWith('guide-media/')||path.startsWith('guide-thumbs/')){
  event.respondWith((async()=>{
   const isThumb=path.startsWith('guide-thumbs/'),name=isThumb?thumbCache:imageCache,key=new URL(url.pathname,url.origin).href,cache=await caches.open(name),saved=await cache.match(key);
   if(saved&&(saved.headers.get('Content-Type')||'').startsWith('image/'))return saved;
   if(saved)await cache.delete(key);
   try{const response=await fetch(request);if(response.ok&&(response.headers.get('Content-Type')||'').startsWith('image/')){try{await cache.put(key,response.clone());}catch{}}if(response.ok)return response;}catch{}
   if(isThumb){const original=await caches.match(new URL(path.replace('guide-thumbs/','guide-media/'),scope).href,{cacheName:imageCache});if(original)return original;}
   return Response.error();
  })());return;
 }
 const entry=path.match(/^guide-entries\/(\d+)\.html$/);
 if(entry){event.respondWith((async()=>{const built=await entryResponse(entry[1]);return built||fetch(request);})());return;}
 const doc=['','index','index.html'].includes(path)?'index.html':['guide','guide.html','guide-mobile','guide-mobile.html'].includes(path)?'guide-mobile.html':['itinerary','itinerary.html'].includes(path)?'itinerary.html':null;
 event.respondWith((async()=>{
  const canonical=doc?new URL(doc,scope).href:request;
  const cached=await caches.match(canonical,{cacheName});if(cached)return doc?clean(cached):cached;
  return fetch(request);
 })());
});
