(function(){
 var d=document,root=d.documentElement,query='',areaMode='',limit=8,complete=false,timer,observer,library=null,libraryTask=null,libraryError=false,lastQuery='';
 var imageQueue=[],imageActive=0,imageObserver;
 function g(id){return d.getElementById(id);}
 function norm(s){s=String(s||'');if(s.normalize)s=s.normalize('NFKC');return s.toLowerCase().replace(/网咖/g,'网吧').replace(/[\s!"#$%&'()*+,\-./:;<=>?@[\\\]^_`{|}~，。！？、：；（）【】「」『』《》“”‘’·…—]/g,'');}
 function nodes(){return Array.prototype.slice.call(d.querySelectorAll('.guide-hit'));}
 function each(list,fn){Array.prototype.forEach.call(list,fn);}
 function closest(el,selector){while(el&&el!==d){if(el.matches&&el.matches(selector))return el;el=el.parentElement;}return null;}
 function libraryStatus(){
  var status=g('guide-load-state'),retry=g('guide-retry-library');if(!status)return;
  status.hidden=!query||!!areaMode||!!library;
  status.textContent=libraryError?'正文检索暂未载入，可先搜索店名或商圈。':'正在检索攻略正文，店名与商圈搜索可先使用。';
  if(retry)retry.hidden=!libraryError||!query;
 }
 function loadLibrary(){
  if(library)return Promise.resolve(library);
  if(libraryTask)return libraryTask;
  libraryError=false;libraryStatus();
  var controller='AbortController'in window?new AbortController():null;
  var timeout=setTimeout(function(){if(controller)controller.abort();},20000);
  libraryTask=fetch('./guide-library.json',controller?{signal:controller.signal}:{}).then(function(r){if(!r.ok)throw Error('Library unavailable');return r.json();}).then(function(data){clearTimeout(timeout);library=data;libraryError=false;libraryStatus();render();return data;}).catch(function(){clearTimeout(timeout);libraryError=true;libraryTask=null;libraryStatus();return null;});
  return libraryTask;
 }
 function activateImages(parent){
  each(parent.querySelectorAll('img'),function(img){
   if(closest(img,'.guide-hit[hidden]'))return;
   if(!img._bound){
    img._bound=true;
    img.addEventListener('load',function(){var frame=closest(img,'.guide-cover,.guide-photo');img.hidden=false;if(frame){var s=frame.querySelector('.image-state'),b=frame.querySelector('.image-retry');if(s)s.hidden=true;if(b)b.hidden=true;}if(img._release){img._release();img._release=null;}});
    img.addEventListener('error',function(){imageFailure(img);});
   }
   if(img.complete&&img.naturalWidth>0){img.dispatchEvent(new Event('load'));return;}
   if(img.getAttribute('data-src')){
    if(imageObserver)imageObserver.observe(closest(img,'.guide-photo')||img);else queueImage(img);
   }else{
    img.loading='eager';
    if(img.complete&&!img.naturalWidth&&!img._retry)retryImage(img); 
   }
  });
 }
 function imageFailure(img){
  img.hidden=true;var frame=closest(img,'.guide-cover,.guide-photo');
  if(frame){var s=frame.querySelector('.image-state'),b=frame.querySelector('.image-retry');if(s){s.textContent=navigator.onLine?'图片暂未载入，请重试。':'这张图片尚未离线保存。';s.hidden=false;}if(b)b.hidden=false;}
  if(img._release){img._release();img._release=null;}
  if(!img._retry&&navigator.onLine){img._retry=1;setTimeout(function(){queueImage(img,true);},700);}
 }
 function queueImage(img,retry){if(!img||img._queued||img._loading&&!retry)return;img._queued=true;imageQueue.push({img:img,retry:retry});pumpImages();}
 function pumpImages(){
  while(imageActive<3&&imageQueue.length){
   (function(job){
    var img=job.img;img._queued=false;if(closest(img,'.guide-hit[hidden]'))return;
    imageActive++;img._loading=true;var released=false;
    img._release=function(){if(released)return;released=true;imageActive--;img._loading=false;pumpImages();};
    var frame=closest(img,'.guide-cover,.guide-photo'),state=frame&&frame.querySelector('.image-state'),button=frame&&frame.querySelector('.image-retry');
    if(state){state.hidden=false;state.textContent='正在载入图片…';}if(button)button.hidden=true;
    var source=img.getAttribute('data-src')||img.getAttribute('data-source')||img.src;
    if(job.retry){img._retry=(img._retry||0)+1;source+=(source.indexOf('?')<0?'?':'&')+'retry='+img._retry;}
    img.hidden=true;img.loading='eager';img.src=source;
    setTimeout(function(){if(!img.complete&&state){state.textContent='图片载入较慢，可点击重试。';if(button)button.hidden=false;if(img._release){img._release();img._release=null;}}},20000);
   })(imageQueue.shift());
  }
 }
 function retryImage(img){if(img)queueImage(img,true);}
 if('IntersectionObserver'in window)imageObserver=new IntersectionObserver(function(items){items.forEach(function(item){if(item.isIntersecting){imageObserver.unobserve(item.target);queueImage(item.target.tagName==='IMG'?item.target:item.target.querySelector('img'));}});},{rootMargin:'350px'});
 function putContent(card,html){
  var content=card.querySelector('.guide-content');content.innerHTML=html+'<p><a class="entry-direct" href="./guide-entries/'+card.getAttribute('data-id')+'.html">单独打开完整攻略 ↗</a></p>';
  content.setAttribute('data-status','ready');activateImages(content);
 }
 function ensureContent(card,force){
  if(!card||!card.open)return;var id=card.getAttribute('data-id'),content=card.querySelector('.guide-content'),state=content.getAttribute('data-status');
  if(state==='ready'){activateImages(content);return;}if(state==='loading'&&!force)return;
  if(library&&library.entries[id]){putContent(card,library.entries[id].html);return;}
  content.setAttribute('data-status','loading');var loading=content.querySelector('.entry-loading'),retry=content.querySelector('.content-retry');
  if(loading){loading.hidden=false;loading.textContent='正在载入完整攻略…';}if(retry)retry.hidden=true;
  var url=new URL('./guide-entries/'+id+'.html',d.baseURI).href;
  var controller='AbortController'in window?new AbortController():null;
  var timeout=setTimeout(function(){if(controller)controller.abort();},25000);
  fetch(url,controller?{signal:controller.signal}:{}).then(function(r){if(!r.ok)throw Error('Entry unavailable');return r.text();}).then(function(text){
   clearTimeout(timeout);var page=new DOMParser().parseFromString(text,'text/html'),article=page.querySelector('.entry-content');if(!article)throw Error('Missing entry');
   each(article.querySelectorAll('img'),function(img){var src=img.getAttribute('src');img.removeAttribute('src');img.setAttribute('data-src',new URL(src,url).href);img.removeAttribute('loading');});
   each(article.querySelectorAll('a[href]'),function(a){a.href=new URL(a.getAttribute('href'),url).href;});
   each(article.querySelectorAll('img'),function(img){var frame=closest(img,'.guide-photo');if(!frame){frame=d.createElement('figure');frame.className='guide-photo';img.parentNode.insertBefore(frame,img);frame.appendChild(img);}var s=d.createElement('span');s.className='image-state';s.textContent='正在载入原攻略图片…';frame.appendChild(s);var b=d.createElement('button');b.className='image-retry';b.type='button';b.hidden=true;b.textContent='重试图片';frame.appendChild(b);});
   putContent(card,article.innerHTML);
  }).catch(function(){
   clearTimeout(timeout);
   if(library&&library.entries[id]){putContent(card,library.entries[id].html);return;}
   content.setAttribute('data-status','error');if(loading){loading.hidden=false;loading.textContent='暂时未载入完整攻略，可以重试或直接打开。';}if(retry)retry.hidden=false;
  });
 }
 function render(){
  var all=nodes(),key=norm(query),hits=[];
  all.forEach(function(n){
   var title=norm(n.getAttribute('data-title')),area=norm(n.getAttribute('data-area')),basic=norm(n.getAttribute('data-basic')),body=library&&library.entries[n.getAttribute('data-id')]?library.entries[n.getAttribute('data-id')].search:'',rank=0,match=false;
   if(areaMode)match=area.indexOf(norm(areaMode))!==-1;
   else if(!key)match=n.getAttribute('data-place')==='1';
   else{match=basic.indexOf(key)!==-1||body.indexOf(key)!==-1;if(key==='t1网吧'&&n.getAttribute('data-id')==='1712')match=true;rank=title===key?2:title.indexOf(key)!==-1?1:0;}
   if(match)hits.push({node:n,rank:rank});
  });
  hits.sort(function(a,b){return b.rank-a.rank||Number(a.node.getAttribute('data-id'))-Number(b.node.getAttribute('data-id'));});
  var visible={};hits.forEach(function(h,i){if(i<limit)visible[h.node.getAttribute('data-id')]=i;});
  all.forEach(function(n){var id=n.getAttribute('data-id'),hide=!Object.prototype.hasOwnProperty.call(visible,id);if(n.hidden!==hide)n.hidden=hide;if(!hide){n.style.order=visible[id];activateImages(n.querySelector('summary'));}else if(n.open)n.open=false;});
  if(g('guide-result-count'))g('guide-result-count').textContent=hits.length+' 个条目';
  if(g('guide-results-title'))g('guide-results-title').textContent=areaMode?areaMode+' · 原文顺序':query?'「'+query+'」的攻略':'攻略里的店与去处';
  if(g('guide-summary')){g('guide-summary').hidden=!!hits.length||!complete||(!library&&!!query);g('guide-summary').textContent='攻略里没找到「'+query+'」。试试店名、商圈或更短的关键词。';}
  if(g('guide-more'))g('guide-more').hidden=limit>=hits.length;
  if(query&&!areaMode&&hits.length&&(query!==lastQuery||!g('guide-results').querySelector('details[open]:not([hidden])'))){all.forEach(function(n){if(n!==hits[0].node)n.open=false;});hits[0].node.open=true;ensureContent(hits[0].node);}
  lastQuery=query;root.setAttribute('data-guide-ready','true');libraryStatus();
 }
 function search(value,area){query=String(value||'').replace(/^\s+|\s+$/g,'');areaMode=area?query:'';limit=8;g('guide-query').value=query;render();if(query&&!areaMode)loadLibrary();}
 d.addEventListener('submit',function(e){if(e.target.id==='guide-search'){e.preventDefault();search(g('guide-query').value,false);}});
 d.addEventListener('toggle',function(e){if(e.target.classList&&e.target.classList.contains('guide-hit')&&e.target.open)ensureContent(e.target);},true);
 d.addEventListener('click',function(e){
  var button=closest(e.target,'.image-retry,.content-retry,#guide-more,#guide-retry-library,[data-query]');
  if(!button)return;e.preventDefault();e.stopPropagation();
  if(button.classList.contains('image-retry'))retryImage(button.parentNode.querySelector('img'));
  else if(button.classList.contains('content-retry'))ensureContent(closest(button,'.guide-hit'),true);
  else if(button.id==='guide-more'){limit+=8;render();}
  else if(button.id==='guide-retry-library')loadLibrary();
  else{var v=button.getAttribute('data-query');search(v,['圣水洞','弘大','明洞','江南'].indexOf(v)!==-1);}
 });
 window.addEventListener('online',function(){if(libraryError&&query)loadLibrary();each(d.querySelectorAll('img'),function(img){if(img.complete&&!img.naturalWidth&&!closest(img,'.guide-hit[hidden]'))retryImage(img);});});
 root.classList.add('guide-enhanced');if(g('guide-search'))g('guide-search').hidden=false;
 function start(){var holder=g('guide-results');if(!holder)return setTimeout(start,10);if(window.MutationObserver){observer=new MutationObserver(function(){clearTimeout(timer);timer=setTimeout(render,70);});observer.observe(holder,{childList:true});}render();}
 window.Guide24={finish:function(){complete=true;if(observer)observer.disconnect();var match=location.hash.match(/^#guide-(\d+)$/);if(match){var target=g('guide-'+match[1]);if(target)query=target.getAttribute('data-title');}render();startOffline();}};
 start();
 function startOffline(){
  var status=g('offline');
  try{if('serviceWorker'in navigator){status.textContent='正在准备离线使用…';navigator.serviceWorker.register('./sw.js',{updateViaCache:'none'}).then(function(){return navigator.serviceWorker.ready;}).then(function(){status.textContent='✓ 可离线使用';},function(){status.textContent='可在线浏览 · 离线保存暂不可用';});}}catch(e){status.textContent='可在线浏览 · 离线保存暂不可用';}
  try{
   if(!window.caches)return;
   var button=g('guide-save-images'),progress=g('guide-download-status'),cacheName='korea-guide-media:'+new URL('./',d.baseURI).href+':v1';g('guide-download').hidden=false;
   button.addEventListener('click',function(){
    button.disabled=true;caches.open(cacheName).then(function(cache){
     var index=1,done=0;
     function one(number,attempt){var name=('000'+number).slice(-3)+'.webp',url=new URL('guide-media/'+name,d.baseURI).href;return cache.match(url).then(function(saved){if(saved&&saved.ok&&(saved.headers.get('Content-Type')||'').indexOf('image/')===0)return saved;return fetch(url).then(function(response){if(!response.ok||(response.headers.get('Content-Type')||'').indexOf('image/')!==0)throw Error('Image unavailable');return cache.put(url,response);});}).then(function(){done++;},function(){if(attempt<2&&navigator.onLine)return new Promise(function(r){setTimeout(r,800);}).then(function(){return one(number,attempt+1);});});}
     function worker(){var number=index++;if(number>745)return Promise.resolve();return one(number,0).then(function(){progress.textContent='已保存 '+done+'/745 张';return worker();});}
     return Promise.all([worker(),worker(),worker(),worker(),worker(),worker()]).then(function(){progress.textContent=done===745?'✓ 全部攻略图片已离线保存':'已保存 '+done+' 张，联网后可继续保存。';button.disabled=done===745;});
    }).catch(function(){progress.textContent='暂时无法保存图片，请稍后重试。';button.disabled=false;});
   });
  }catch(e){}
 }
})();
